@extends('auth.index')

@section('style')
    <style>
        .login-box{
            width: 700px;
            transform: translate(-50%, 0%);
            top:unset;
        }
    </style>
@endsection

@section('content')
<form id="sign_up" method="POST" action="">
    <h3>Tính năng này đang phát triển</h3>
</form>
@endsection
@section('script')

@endsection