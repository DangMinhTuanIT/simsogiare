@extends('auth.index')

@section('title', 'ĐĂNG NHẬP')

@section('content')
    <div class="card">
        <div class="body">
            <h3>Không thể truy cập</h3>
            <a href="javascript:history.go(-1);" class="btn bg-teal waves-effect">Trở lại trang trước</a>
        </div>
    </div>
@endsection
