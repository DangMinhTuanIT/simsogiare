<div class='block_sims_filter sims_filter-_simsfilter sims_filter_0 block'  id = "block_id_188" >
   <div class='sims_filter'>
     <div class="block_strengths strengths-_strengths strengths_1 block" id="block_id_198">
   <div class="strengths_vertical_block cls">
      <div class="sims_years sub_block">
         <div class="sub_block_title info_title_block service-sim" data-id="id_info" id="sub_block_title">
            <div class="normal"><span>DỊCH VỤ SIM</span></div>
         </div>
         <div class="fillter_categories_label" id="id_info">
            <div class="years_body summary">
               <div class="info_item">
                  <div class="years_item_inner">
                     <div class="info_inner">
                        Thu mua SIM             
                     </div>
                     
                  </div>
               </div>
               <div class="info_item">
                  <div class="years_item_inner">
                     <div class="info_inner">
                        Cầm SIM             
                     </div>
                    
                  </div>
               </div>
               <div class="info_item">
                  <div class="years_item_inner">
                     <div class="info_inner">
                        SIM trả góp                
                     </div>
                     
                  </div>
               </div>
               
            </div>

         </div>
          <div class="contact">
               <div class="tit-contact">Liên hệ ngay</div>
               <div class="phone"><a href="">0909.234.234</a> - <a href="">0919.234.234</a></div>
            </div>
         <!-- end .sims_categories_label -->
      </div>
      <!-- end .sims_years_cols_right -->
      <div class="clear"></div>
   </div>
</div>
@php $segment1 =  Request::segment(1);  @endphp
       
      {!!WebService::sidebar_sim(@$type_sidebar,@$slug1)!!}
   </div>
   <div class="clear"></div>
</div>
<div class='block_strengths strengths-_strengths strengths_1 block'  id = "block_id_198" >
   <div class='strengths_vertical_block cls'>
      <div class='sims_years sub_block' >
         <div class='sub_block_title info_title_block' data-id ='id_info' id="sub_block_title">
            <div class="normal"><span>Thông tin cần biết</span></div>
         </div>
         <div class='fillter_categories_label' id="id_info">
            <div class='years_body summary'>
               <div class='info_item'>
                  <div class='years_item_inner'>
                     <div class="info_inner">
                        Kiểm tra sim còn hay đã bán                
                     </div>
                     <div class="summary">
                        <p>Gọi điện đến số sim đ&oacute; v&agrave; lắng nghe th&ocirc;ng b&aacute;o:</p>
                        <ul>
                           <li>Nếu c&oacute; Đổ chu&ocirc;ng th&igrave; số sim đ&oacute; KH&Ocirc;NG C&Ograve;N TRONG KHO&nbsp;<em>(trừ d&ograve;ng Sim Vip)</em></li>
                           <li>Nếu tổng đ&agrave;i b&aacute;o &quot;Tạm thời kh&ocirc;ng li&ecirc;n lạc được&quot; hoặc &quot;Đang tạm kh&oacute;a&quot; th&igrave; bạn vui l&ograve;ng GỌI CHO MUA SIM để được hỗ trợ kiểm tra ch&iacute;nh x&aacute;c.</li>
                           <li>Nếu tổng đ&agrave;i b&aacute;o &quot;Số điện thoại kh&ocirc;ng đ&uacute;ng&quot; hoặc &quot;Thu&ecirc; bao vừa gọi kh&ocirc;ng đ&uacute;ng&quot; th&igrave; số sim đ&oacute; VẪN C&Ograve;N TRONG KHO v&agrave; Qu&yacute; kh&aacute;ch c&oacute; thể đặt mua số sim n&agrave;y tại <span style="color:#ff0000"><strong><span style="background-color:#ecf0f1">Muasim.com.vn</span></strong></span></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class='info_item'>
                  <div class='years_item_inner'>
                     <div class="info_inner">
                        Cách thức mua sim và thanh toán                
                     </div>
                     <div class="summary">
                        <ul>
                           <li><span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:14px">Đặt mua sim tr&ecirc;n website hoặc điện Hotline</span></span></li>
                           <li><span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:14px">NVKD sẽ gọi lại tư vấn v&agrave; x&aacute;c nhận đơn h&agrave;ng</span></span></li>
                           <li><span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:14px">Nhận sim tại nh&agrave;, kiểm tra th&ocirc;ng tin ch&iacute;nh chủ v&agrave; thanh to&aacute;n cho người giao sim</span></span></li>
                           <li>
                              <span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:14px">Th&ocirc;ng tin ng&acirc;n h&agrave;ng:</span></span>
                              <ul>
                                 <li><span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:14px">Chủ TK: ĐO&Agrave;N THANH TUNG<br />
                                    Số TK: <strong><span style="color:#ff0000">19031769259019</span></strong><br />
                                    Ng&acirc;n h&agrave;ng:&nbsp;Techcombank&nbsp;&nbsp;Việt Nam - CN Ho&agrave;ng Mai -&nbsp;H&agrave; Nội</span></span>
                                 </li>
                                 <li><span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:14px">Chủ TK: ĐO&Agrave;N THANH TUNG<br />
                                    Số TK: <strong><span style="color:#ff0000">0021002287215</span>&nbsp;</strong><br />
                                    Ng&acirc;n h&agrave;ng: Vietcombank Việt Nam - CN Ho&agrave;ng Mai -&nbsp;H&agrave; Nội</span></span>
                                 </li>
                              </ul>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class='info_item'>
                  <div class='years_item_inner'>
                     <div class="info_inner">
                        Kiểm tra thông tin chính chủ               
                     </div>
                     <div class="summary">
                        <ul>
                           <li><span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:16px"><strong><span style="color:#ff0000">Soạn tin&nbsp;TTTB&nbsp;gửi&nbsp;1414</span></strong></span></span></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class='info_item'>
                  <div class='years_item_inner'>
                     <div class="info_inner">
                        Cam kết bán hàng               
                     </div>
                     <div class="summary">
                        <ul>
                           <li><span style="font-size:14px"><span style="color:#ff0000"><strong><em>Cam kết&nbsp;1</em></strong></span>: Lu&ocirc;n trả lời cho kh&aacute;ch h&agrave;ng biết sim c&oacute; hay kh&ocirc;ng c&oacute;, c&ograve;n hay đ&atilde; b&aacute;n.</span></li>
                           <li><span style="font-size:14px"><span style="color:#ff0000"><strong><em>Cam kết&nbsp;2</em></strong></span>: Ho&agrave;n tiền 100% nếu sim bị thất lạc hoặc do sai s&oacute;t của Muasim.com<strong>.vn</strong>&nbsp;dẫn đến giao dịch kh&ocirc;ng th&agrave;nh c&ocirc;ng.</span></li>
                           <li><span style="font-size:14px"><strong><em><span style="color:#ff0000">Cam kết&nbsp;3</span></em></strong>: Đăng k&yacute; th&ocirc;ng tin ch&iacute;nh chủ, đảm bảo quyền sở hữu số sim theo đ&uacute;ng quy định của ph&aacute;p luật.</span></li>
                           <li><span style="font-size:14px"><span style="color:#ff0000"><em><strong>Cam kết&nbsp;4</strong></em></span>: Giữ b&iacute; mật tuyệt đối th&ocirc;ng tin của kh&aacute;ch h&agrave;ng</span></li>
                           <li><span style="font-size:14px"><span style="color:#ff0000"><em><strong>Cam kết&nbsp;5</strong></em></span>: B&aacute;n đ&uacute;ng gi&aacute; v&agrave; lu&ocirc;n cố gắng b&aacute;n gi&aacute; thấp nhất c&oacute; thể so với c&aacute;c số sim tương tự đang c&oacute; tr&ecirc;n thị trường.</span></li>
                           <li><span style="font-size:14px"><span style="color:#ff0000"><em><strong>Cam kết&nbsp;6</strong></em></span>: Giao sim miễn ph&iacute; tr&ecirc;n to&agrave;n quốc. Kh&aacute;ch h&agrave;ng kh&ocirc;ng phải trả th&ecirc;m bất cứ khoản ph&iacute; n&agrave;o khi nhận sim.</span></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class='info_item'>
                  <div class='years_item_inner'>
                     <div class="info_inner">
                        Thông tin kế toán                
                     </div>
                     <div class="summary">
                        <ul>
                           <li><span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:14px"><strong>Kế to&aacute;n</strong>: Trần Thị Thương</span></span></li>
                           <li><span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:14px">Mobile:&nbsp; 0912.178.178</span></span></li>
                           <li><span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:14px">Zalo: 0912.178.178</span></span></li>
                        </ul>
                        <p><span style="font-family:Arial,Helvetica,sans-serif"><span style="font-size:14px">Mọi y&ecirc;u cầu về c&ocirc;ng nợ đại l&yacute; - thanh to&aacute;n xin li&ecirc;n hệ th&ocirc;ng tin tr&ecirc;n</span></span></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- end .sims_categories_label -->
      </div>
      <!-- end .sims_years_cols_right -->
      <div class='clear'></div>
   </div>
</div>
{!!WebService::order_sim_lastest()!!}