@include('frontend.common.head')
@include('frontend.common.header')
<main id="site-content" class="site-content clear 123">
        @yield('content')
</main>
@include('frontend.common.footer')



