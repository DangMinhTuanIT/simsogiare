@extends('home')

@section('title', 'UPLOAD FILE')

@section('style')
    @parent
@endsection

@section('content')
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <h2>
                        UPLOAD FILE
                    </h2>
                </div>
                <div class="body center upload-completed">
                    Tính năng này đang phát triển
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')

@endsection