@extends('home')
@section('title', $module_name)
@section('style')
@parent

@endsection
@section('content')
<form class="form_validation collapse{{ (old('data')) ? ' in' : '' }} in" enctype="multipart/form-data"  id="formDemo" action="{{route('genre.update_db',array($info->id))}}" method="post" role="form">
  <input type="hidden" name="_method" value="PUT">
   <input type="hidden" name="_token" value="{{ csrf_token() }}">
   <!-- Input Group -->
   <div class="row clearfix"> 
    <div class="col-lg-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                   
                    Thông tin về thể loại
                
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <label><label for="name_network">Tên thể loại</label></label>
                        <input type="text" id="name_genre" name="name_genre" value="{{$info->name_genre}}" class="form-control title_slugify" placeholder="Tên thể loại SIM, ví dụ: Sim tứ quý">                    </div>
                    <div class="form-group">
                        <label><label for="status">Trạng thái</label></label>
                        <select id="status" name="status" class="form-control">
                            @foreach(config('simsogiare.status_category_network') as $key => $item)
                             @php $active = $info->status==$key ? 'selected="selected"' : '' @endphp
                            <option {{$active}} value="{{$key}}">{{$item}}</option>
                            @endforeach
                        </select>                        
                        <p class="help-block">Tình trạng active sẽ được hiển thị ở trang chủ.</p>
                    </div>
                    <div class="form-group">
                        <label><label for="weight">Vị trí</label></label>
                        <select id="weight" name="weight" class="form-control">
                            @for($i=1;$i<25;$i++)
                            @php $active = $info->weight==$i ? 'selected="selected"' : '' @endphp
                            <option {{$active}} value="{{$i}}">{{$i}}</option>
                            @endfor
   
</select>                    
                      <p class="help-block">Vị trí sắp xếp của thể loại, số nhỏ đứng trước. Chú ý sẽ ảnh hưởng tới kết quả tự động nhận dạng nếu sai vị trí. Ví dụ bạn không thể để thể loại "tam hoa" đứng trước "tứ quý"

</p>
                    </div>
                    <div class="form-group">
                        <label><label for="type_sidebar">Sidebar</label></label>
                        <select id="type_sidebar" name="type_sidebar" class="form-control">
                            @php $type_sidebar = array(
                            'sim_tao_thuong_hieu'=>'Sim Tạo Thương Hiệu',
                            'sim_vip_doanh_nhan'=>'Sim Vip Doanh Nhân',
                            'sim_sinh_tai_loc'=>'Sim Sinh Tài Lộc',
                            ); @endphp
                            @foreach($type_sidebar as $key => $item)
                            @php $active = $info->type_sidebar==$key ? 'selected="selected"' : '' @endphp
                            <option {{$active}} value="{{$key}}">{{$item}}</option>
                            @endforeach
                        </select>                       
                    </div>
                   <div class="form-group">
                        <label><label for="regex">Chuỗi nhận dạng</label></label>
                        <input type="text" id="regex" name="regex" value="{{$info->regex}}" class="form-control" placeholder="Tự động nhận dạng lúc import SIM" data-max-length="1">                        <p class="help-block">
                            Là mẫu để tự động nhận dạng SIM thuộc thể loại này. Ví dụ muốn nhận dạng sim kép có số 1 và 2: <b>/(1122|2211)$/</b>
                        </p>
                    </div>
                    <div class="form-group">
                        <label><label for="detect">Số SIM mẫu</label></label>
                        <input type="text" id="detect" name="detect" value="{{$info->detect}}" class="form-control" placeholder="Số SIM mẫu thuộc thể loại này" data-max-length="1">                    </div>
                         <div class="form-group form-float ">
                        <div><label for="weight">Mô tả ngắn</label></div>
                        <textarea name="description" id="" cols="60" rows="4">{{$info->description}}</textarea>
                      </div>
                       <div class="form-group form-float ">
                        <div><label for="weight">Nội dung chính</label></div>
                        <textarea name="content" id="description" cols="20" rows="5">{{$info->content}}</textarea>
                      </div>
                <button type="submit" class="btn btn-primary">Cập nhật</button>
                    <a type="button" href="{{route('genre.list')}}" class="btn btn-default">Quay lại</a>
                <!-- /.panel-body -->
            </div>
          </div>
            <!-- /.panel -->
        </div>
       <div class="col-lg-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Thông tin về SEO
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <label><label for="alias">Đường dẫn</label></label>
                        <input type="text" id="alias" name="alias" value="{{$info->slug}}" class="form-control slug_slugify" placeholder="Đường dẫn thân thiện">                        <p class="help-block">Chỉ được sử dụng các từ a-z 0-9 dấu gạch ngang (-). Ví dụ: viettel. Nếu không nhập thì được tạo từ động từ tên của nhà mạng</p>
                    </div>
                    <div class="form-group">
                        <label><label for="meta_title">Tiêu đề của trang</label></label>
                        <input type="text" id="meta_title" name="meta_title" value="{{$info->seo_title}}" class="form-control" placeholder="Tiêu đề của trang" maxlength="128">                    </div>
                    <div class="form-group">
                        <label><label for="meta_keywords">Từ khóa</label></label>
                        <input type="text" id="meta_keywords" name="meta_keywords" value="{{$info->seo_keyword}}" class="form-control auto-tags" placeholder="Từ khóa của trang, mỗi từ khóa cách nhau bằng dấu phẩy" maxlength="128">                    </div>
                    <div class="form-group">
                        <label><label for="meta_description">Trích dẫn</label></label>
                        <textarea id="meta_description" name="meta_description" value="{{$info->seo_description}}" class="form-control" placeholder="Trích dẫn của trang">{{$info->seo_description}}</textarea>                    </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
                  </div>
               
           
</form>
@include('filters')
@endsection
@section('script')
@include('general.layouts.data-table-scripts')
@include('admin.genre.scripts')

@endsection