<h2 style="margin-bottom: 0;">Thông tin khách hàng</h2><br/>
<table style="border: 1px solid #1C6EA4;background-color: #f3fff2;text-align: left;border-collapse: collapse;font-size: 15px;">
    <tr>
        <td style=" border: 1px solid #AAAAAA;padding: 8px;"><strong>Họ tên</strong></td>
        <td style=" border: 1px solid #AAAAAA;padding: 8px;">{{ $name }}</td>
    </tr>
    <tr>
        <td style=" border: 1px solid #AAAAAA;padding: 8px;"><strong>Email</strong></td>
        <td style=" border: 1px solid #AAAAAA;padding: 8px;">{{ $email }}</td>
    </tr>
    <tr>
        <td style=" border: 1px solid #AAAAAA;padding: 8px;"><strong>Điện thoại</strong></td>
        <td style=" border: 1px solid #AAAAAA;padding: 8px;">{{ $phone }}</td>
    </tr>
    <tr>
        <td style=" border: 1px solid #AAAAAA;padding: 8px;"><strong>Nguồn</strong></td>
        <td style=" border: 1px solid #AAAAAA;padding: 8px;">{{ $source_description }}</td>
    </tr>
    <tr>
        <td style=" border: 1px solid #AAAAAA;padding: 8px;"><strong>Ngày tạo</strong></td>
        <td style=" border: 1px solid #AAAAAA;padding: 8px;">{{ $created_at }}</td>
    </tr>
</table>